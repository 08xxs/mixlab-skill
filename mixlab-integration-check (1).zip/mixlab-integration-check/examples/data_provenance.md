# 数据来源与标签约定

本 Skill 要求每个 study 配置声明 `data_provenance`，并把它写进审计 JSON、图表标题与运行清单。

| 标签 | 含义 | 允许用途 |
| --- | --- | --- |
| `MEASURED` | 本实验室原始测量 | 可作为实验结论依据 |
| `PUBLIC_EXPERIMENTAL` | 公开论文/数据库的实测数据 | 可做建模与回放验证，需注明来源 |
| `RECONSTRUCTED` | 从图表/论文重建 | 需说明重建方法，结论降级 |
| `SIMULATED` | 程序模拟或人工构造 | 仅用于流程测试 |
| `SYNTHETIC` | 合成数据 | 仅用于流程测试 |

预测值统一标记 `PREDICTED`，候选方案统一标记 `UNVERIFIED_RECOMMENDATION`。

## 关于 `assets/sample_input_SIMULATED.csv`

由脚本按近似线性关系构造，用于 `tests/test_end_to_end.py` 的可重复验证。
它与真实科研无关，不得作为实验结果引用。

## 关于 `Dye_dataset_r.xlsx`

项目团队提供的染料降解文献汇编（304 条）。原始表存在两处结构问题，已在导入前处理并记录：

1. 第 1 行是导出残留的索引行，真正表头在第 2 行；
2. 表头单元格含多余单引号（如 `'Material'`）。

处理方式：按第 2 行重建列名并去引号，生成 `Dye_dataset_r_analysis.csv` 作为分析输入，
原始 xlsx 不改动。`Material` / `Dye` 为类别编码，不参与数值建模；
`Surface area` 缺失 171/304（56.3%），未纳入变量。
