---
name: mixlab-integration-check
description: MixLab 实验设计与参数优化管线。当用户上传实验数据（CSV 或 Excel）并需要数据审计、模型验证，或询问「下一轮实验该做哪些参数」时使用。执行可复现的本地 Python 管线：数据审计 → 基线对照与模型评估（含质量门）→ 在有界范围内搜索候选参数 → 输出 candidate_experiments.csv、图表、研究报告与运行清单；并提供回放验证，比较模型推荐与随机挑选。旧的 CSV 集成测试 integration_check.py 保持不变。
---

# mixlab-integration-check

本包含三个入口，用途不同。

| 入口 | 用途 | 状态 |
| --- | --- | --- |
| `scripts/run_mixlab.py` | **正式管线**：审计 → 建模 → 质量门 → 有界候选推荐 → 图表 → 报告 | v0.3（PRD V2.0 P0-FR01…FR05） |
| `scripts/replay_validate.py` | **回放验证**：同预算下比较「模型推荐 / 随机 / 就近最佳」 | v0.3（PRD §8.1 第 3 层） |
| `scripts/integration_check.py` | 旧的 CSV 集成测试（单文件线性回归） | v1.0，**代码与历史证据保持不变** |

> 事实边界：Mira Skill 是「说明 + 随包脚本」的指令包，不是平台原生插件。
> 「调用 Skill」= 按本文件命令实际执行脚本。只展示代码、不产生输出文件，不算调用成功。

## 1. 硬性规则

1. **必须实际执行** `run_mixlab.py`，不得只给代码或口头结论。
2. **目标列必须由用户显式给出**；缺失时返回 `BLOCKED_INPUT`，禁止猜列。
3. **异常值只标记不删除**（`cleaning.policy = flag_only`）；任何剔除都要用户明确要求并写入配置。
4. **不得编造**指标、候选或图表；失败就输出阻断状态与原因。
5. 候选方案一律标记 `UNVERIFIED_RECOMMENDATION`，不得称为实验结果。
6. 图表内文字使用英文（避免 CJK 字体缺字），报告正文用中文；字段名与数值不得改动。

## 2. 输入契约

**数据**：`.csv / .tsv / .txt / .xlsx`。CSV 依次尝试 `utf-8-sig → gb18030 → latin-1` 并按 `, ; \t |` 嗅探分隔符；Excel 读第一个工作表并在 manifest 记录表名。原始文件只读，不覆盖。

**配置**（JSON，必需字段缺一即 `BLOCKED_INPUT`）：

| 字段 | 必需 | 说明 |
| --- | --- | --- |
| `target_column` | ✅ | 单个数值型目标列，**必须显式指定** |
| `data_provenance.type` / `.source` | ✅ | `PUBLIC_EXPERIMENTAL` / `MEASURED` / `SIMULATED` / `RECONSTRUCTED` + 来源 URL/DOI |
| `objective.direction` | ✅ | `maximize` / `minimize` / `target`（后者需 `target_value`） |
| `variables` | ✅ | 每个变量：`role`（controllable / context）、`unit`；controllable 需 `bounds: [lo, hi]`；context 需 `fixed_value` |
| `split` | 建议 | `method`（random / group）、`seed`（默认 42）、`test_size`（默认 0.2）；group 需 `group_column` |
| `recommendation` | 建议 | `top_k`（默认 3，≤10）、`candidate_budget`（默认 200）、`grid_levels`、`min_separation` |
| `model` | 可选 | `target_transform`（none / log / log10）、`rf_min_train` |
| `quality` | 可选 | `min_rows`、`min_mae_improvement_pct`（默认 5）、`min_test_rows_for_r2` |

样例：`config/example_config.json`（SIMULATED 演示）、`config/dye_study.json`（真实数据）。

## 3. 执行

```bash
python3 <skill_dir>/scripts/run_mixlab.py \
  --input <数据文件> \
  --config <study.json> \
  --outdir <输出目录>
```

自检（不依赖用户数据）：

```bash
python3 <skill_dir>/tests/test_end_to_end.py
```

## 4. 输出契约

| 文件 | 内容 |
| --- | --- |
| `run_config.json` | 原始配置 + 解析结果（实际使用的样本量、有效边界、候选生成模式） |
| `data_audit.json` | 行列数、dtype、缺失、重复、常量列、IQR 可疑值、目标分布 |
| `model_metrics.json` | 划分信息、各模型训练/测试 MAE/RMSE/R²、训练内 CV MAE、质量门结论 |
| `predictions.csv` | 测试集：原始行号、真实值、预测值、残差 |
| `candidate_experiments.csv` | 候选参数、`predicted_target`、`rank`、`risk_flags`、`reason`（阻断时不生成） |
| `figures/data_overview.png` | 缺失率 + 目标分布 |
| `figures/target_distribution.png` | 目标变量分布 |
| `figures/pred_vs_actual.png` | 测试集真实值 vs 预测值 |
| `figures/candidate_comparison.png` | Top-K 候选 vs 训练数据分布 |
| `figures/candidate_ranking.png` | 候选预测值排序 |
| `research_report.md` | 研究目标 → 数据来源 → 验证方法 → 观察 → 候选 → 局限 |
| `run_manifest.json` | 命令、版本、种子、输入/输出哈希、状态、错误 |

## 4.1 回放验证（推荐是否优于随机）

推荐功能「能跑」不等于「有效」。这一步用历史数据回答后者：

```bash
python3 <skill_dir>/scripts/replay_validate.py \
  --input <数据文件> --config <study.json> \
  --outdir <输出目录> --repeats 20 --top-k 3
```

做法：每折按配置划分训练池/留出池（有 `group_column` 时按组划分，避免同源泄漏），
模型**仅在训练池内用交叉验证挑选**；候选池是留出集中满足 bounds 的真实条件，用其**实测**目标打分。
同预算 k 下比较三种策略：

| 策略 | 含义 |
| --- | --- |
| model | 用与 `recommend.py` 相同的排序 + 多样性规则挑选 |
| random | 从候选池均匀抽 k 条，重复 200 次得到分布 |
| nearest-best-run | 挑离「训练集最佳实验」最近的 k 条（人类常用启发式） |

输出：`replay_validation.json`、`figures/replay_comparison.png`、`replay_report.md`。

判定规则（写入 JSON 的 `verdict`）：

| verdict | 条件 |
| --- | --- |
| `EVIDENCE_OF_ADVANTAGE` | 中位提升 > 0 且 ≥70% 折次高于随机均值 且 ≥50% 折次超过随机 95 分位 |
| `WEAK_OR_INCONCLUSIVE` | 中位提升 > 0 但未同时满足上面两条 |
| `NO_EVIDENCE_OVER_RANDOM` | 中位提升 ≤ 0 |

注意：目标分布右偏时**均值提升会被极端值放大**，以 `median_improvement_vs_random_pct` 为准；
`model_vs_oracle_median_ratio` 表示模型达到「事后最优 k 条」上界的比例。
回放只检验「在历史条件中择优」的能力，不检验前瞻性实验价值。

## 5. 阻断状态与退出码

| 状态 | 退出码 | 触发条件 | 行为 |
| --- | --- | --- | --- |
| `OK` | 0 | 全链路通过 | 输出候选清单 |
| `FAILED_RUNTIME` | 1 | 未预期异常 / 依赖缺失 | 记录 traceback |
| `BLOCKED_INPUT` | 2 | 目标列缺失/非数值、变量或 bounds 缺失、`lower>=upper`、来源缺失、JSON 非法 | 停止，不猜 |
| `BLOCKED_DATA` | 3 | 去缺失后行数 < `min_rows`、目标无变化 | 停止 |
| `BLOCKED_MODEL_QUALITY` | 4 | 最佳模型未能比均值基线好 `min_mae_improvement_pct` | 输出审计与指标，**不生成候选** |
| `BLOCKED_CONSTRAINTS` | 5 | 用户边界与数据范围无交集、候选全被过滤 | 停止 |

阻断时仍写出 `run_config.json`、`data_audit.json`、`research_report.md`、`run_manifest.json`——这是「记录失败」，不是部分成功。

## 6. 验收清单

- [ ] CLI 真实执行，退出码与 `run_manifest.json` 一致。
- [ ] `data_audit.json` 的缺失/重复统计与独立 pandas 计算一致。
- [ ] `model_metrics.json` 中训练+测试行数等于 `rows_used`。
- [ ] 质量门未通过时，目录下**没有** `candidate_experiments.csv`。
- [ ] 候选全部落在 `variables.*.bounds` 内，且每条带 `UNVERIFIED_RECOMMENDATION`。
- [ ] 图与 CSV 数值一致（候选排名图标签 = `rank` + `candidate_id`）。
- [ ] 输入 SHA-256 与 `sha256sum <数据文件>` 一致。

## 7. 故障排查

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| exit 2 提到 `target_column` | 未显式指定目标列 | 让用户确认目标列名，禁止猜 |
| exit 2 提到 `bounds 冲突` | `lower >= upper` | 请用户给出正确上下限 |
| exit 2 提到 `role`/`unit` | 变量配置不完整 | 补 `role` + `unit`（controllable 还要 bounds） |
| exit 3 | 样本过少或目标恒定 | 说明数据不足，请用户补充 |
| exit 4 | 模型打不过均值基线 | 如实报告，不硬推参数；可建议换特征或加数据 |
| exit 5 | 边界与数据无交集 | 请用户放宽或修正边界 |
| 图表中文方块 | 缺 CJK 字体 | 图内保持英文，勿改图例文字 |
