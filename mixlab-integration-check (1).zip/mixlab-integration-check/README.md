# mixlab-integration-check (v0.2)

Mira 自定义 Skill：上传实验数据 → 数据审计 → 模型验证 → **下一轮实验参数候选** → 图表与证据。

旧版 `scripts/integration_check.py`（v1.0 CSV 集成测试）完整保留，未做任何修改；本版本是新增入口。

## 包内结构

```
mixlab-integration-check/
├── SKILL.md                      触发条件、输入契约、执行命令、阻断语义、验收清单
├── README.md                     本文件
├── requirements.txt
├── config/
│   ├── example_config.json       SIMULATED 演示配置
│   ├── dye_study.json            真实 Dye 数据配置（含取值说明）
│   ├── dye_study_group.json      同上，按 DOI 分组划分
│   └── control_sim_replay.json   回放阳性对照配置
├── scripts/
│   ├── run_mixlab.py             统一入口（FR01 校验 + 编排 + 清单）
│   ├── replay_validate.py        §8.1 回放验证（推荐 vs 随机 vs 就近最佳）
│   ├── audit.py                  FR02 数据审计
│   ├── train.py                  FR03 建模/验证/质量门
│   ├── recommend.py              FR04 有界候选搜索与风险标记
│   ├── visualize.py              FR05 图表
│   ├── report.py                 FR05 报告
│   ├── common.py                 共享工具（读取/哈希/绘图样式）
│   ├── integration_check.py      【旧】v1.0 集成测试，未改动
│   └── selftest.sh               【旧】自检脚本
├── assets/sample_input_SIMULATED.csv
├── assets/control_sim_240.csv    回放阳性对照（已知线性结构）
├── tests/test_end_to_end.py      25 项断言，含 3 个必测用例
└── examples/                     数据来源与标签说明
```

## 安装

同前：技能管理 → 添加技能 → 上传 `.skill` / `.zip`。装完刷新列表应看到 `mixlab-integration-check`。

装完**必须**先自检，确认脚本能在你的环境跑：

```bash
python3 <skill_dir>/tests/test_end_to_end.py
```

期望最后一行 `ALL TESTS PASSED`。

## 调用

```bash
python3 <skill_dir>/scripts/run_mixlab.py \
  --input 你的数据.csv \
  --config config/dye_study.json \
  --outdir outputs/run_001
```

配置文件怎么改见 `SKILL.md` 第 2 节；最常改的是 `target_column`、`objective.direction`、`variables.*.bounds`。

## 验证

| 检查 | 方法 | 期望 |
| --- | --- | --- |
| 真跑了 | 终端 JSON | `status` 与 `run_manifest.json` 一致 |
| 输入被读取 | manifest `input.sha256` | 等于 `sha256sum 数据文件` |
| 审计可信 | `data_audit.json` | 缺失/重复数与 pandas 独立计算一致 |
| 质量门有效 | 查看 `model_metrics.json.gate` | 未通过时目录下没有 `candidate_experiments.csv` |
| 候选合规 | `candidate_experiments.csv` | 全部在 `bounds` 内，`data_label=UNVERIFIED_RECOMMENDATION` |
| 可复现 | 同命令跑两次 | `predictions.csv` 完全一致（固定 seed） |

## 回放验证（推荐是否真的更好）

```bash
python3 <skill_dir>/scripts/replay_validate.py \
  --input 数据.csv --config config/dye_study_group.json \
  --outdir outputs/replay --repeats 20 --top-k 3
```

每折按组划分训练/留出，模型只在训练池内做交叉验证选型，再用留出集中满足 bounds 的**真实条件**
做同预算比较。重点看三个数：

| 字段 | 怎么读 |
| --- | --- |
| `median_improvement_vs_random_pct` | 主判据；>0 才算有方向性优势 |
| `beat_random_p95_pct` | ≥50% 才谈得上统计上站得住 |
| `model_vs_oracle_median_ratio` | 模型达到「事后最优 k 条」的比例，1.0 为上限 |

`verdict` 会给出 `EVIDENCE_OF_ADVANTAGE` / `WEAK_OR_INCONCLUSIVE` / `NO_EVIDENCE_OVER_RANDOM`。
它只检验「在历史条件中择优」，不检验前瞻性价值。

## 能力边界（已实现 / 未实现）

| PRD 条目 | 状态 | 说明 |
| --- | --- | --- |
| P0-FR01 输入与配置校验 | ✅ 已实现 | 缺字段/边界冲突/目标列非法 → 退出码 2 |
| P0-FR02 数据审计 | ✅ 已实现 | `data_audit.json` + `figures/data_overview.png`；只标记不删除 |
| P0-FR03 模型与验证 | ✅ 已实现（random / group 两种划分） | 基线 + 线性 + 随机森林；Pipeline 内拟合；质量门 |
| P0-FR03 时间序列划分 | ❌ 未实现 | `split.method=time` 会明确报错，不静默降级 |
| P0-FR04 候选推荐 | ✅ 已实现 | 有界网格/随机搜索、多样性、风险标记、阻断 |
| P0-FR05 图表与报告 | ✅ 已实现 | 5 张图 + `research_report.md` |
| P0-FR06 归档与复现 | ✅ 已实现 | 哈希、配置、版本、种子、退出码全记录 |
| P1-FR07 效率基准 | ❌ 未实现 | 未做人工流程耗时对照，不宣称任何提升比例 |
| 真实数据外部验证（AC-10） | ⚠️ 部分 | Dye 数据跑通，但每条 DOI 未逐条核验，属团队待办 |
| 回放验证（§8.1 第 3 层） | ✅ 已实现 | `replay_validate.py`：同预算下模型 vs 随机 vs 就近最佳 |

## 关于候选方案

`candidate_experiments.csv` 里的 `predicted_target` 全部是**模型预测**，标记为
`UNVERIFIED_RECOMMENDATION`。风险标记含义：

| 标记 | 含义 |
| --- | --- |
| `SPARSE_NEIGHBORHOOD` | 标准化空间中距最近训练样本 > 1.5，局部数据稀疏 |
| `OUTSIDE_TRAIN_P05_P95` | 某个可调变量落在训练数据 5%–95% 分位之外 |
| `PREDICTED_OUTSIDE_OBSERVED_RANGE` | 预测值超出观测到的目标范围（外推） |
| `SMALL_SAMPLE` | 训练样本 < 50，模型本身不稳定 |

这些是**风险提示**，不是校准过的置信区间。

## 版本

- 技能内容版本：`0.3.0`（`run_mixlab.py` / `replay_validate.py` 内 `SKILL_VERSION`）
- 旧入口版本：`1.0.0`（保持不变）
- 平台登记版本：由技能管理页生成，与上面两者含义不同
