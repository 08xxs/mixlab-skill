# Run the bundled demo self-test.
# Usage: bash scripts/selftest.sh [output_dir]
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(dirname "$HERE")"
OUT="${1:-./selftest_output}"
PY="${PYTHON:-python3}"

echo "[selftest] python : $("$PY" -c 'import sys; print(sys.version.split()[0])')"
echo "[selftest] skill  : $SKILL_DIR"
echo "[selftest] output : $OUT"

"$PY" "$HERE/integration_check.py" \
  --input "$SKILL_DIR/assets/sample_input_SIMULATED.csv" \
  --outdir "$OUT" \
  --tag "bundled-demo"

echo "[selftest] done. Files:"
ls -l "$OUT"
